namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Seller")]
    public partial class Seller
    {
        public Seller()
        {
            CompleteOrders = new HashSet<CompleteOrder>();
            Items = new HashSet<Item>();
            Orders = new HashSet<Order>();
        }

        public int SellerId { get; set; }

        public int AccountId { get; set; }

        [Required]
        [StringLength(50)]
        public string SellerName { get; set; }

        public virtual Account Account { get; set; }

        public virtual ICollection<CompleteOrder> CompleteOrders { get; set; }

        public virtual ICollection<Item> Items { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
