namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Comment")]
    public partial class Comment
    {
        public int CommentId { get; set; }

        public int AccountId { get; set; }

        public int ItemId { get; set; }

        public DateTime CommentTime { get; set; }

        [Required]
        public string CommentContent { get; set; }

        public decimal Rating { get; set; }

        public virtual Account Account { get; set; }

        public virtual Item Item { get; set; }
    }
}
