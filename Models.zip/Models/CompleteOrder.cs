namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CompleteOrder")]
    public partial class CompleteOrder
    {
        public int CompleteOrderId { get; set; }

        public int OrderId { get; set; }

        public DateTime OrderReceiveTime { get; set; }

        public int AccountId { get; set; }

        public int SellerId { get; set; }

        public DateTime OrderTime { get; set; }

        public int ItemId { get; set; }

        public int OrderQuantity { get; set; }

        [Column(TypeName = "money")]
        public decimal ItemAfterDiscountPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal OrderTotal { get; set; }

        public virtual Account Account { get; set; }

        public virtual Item Item { get; set; }

        public virtual Order Order { get; set; }

        public virtual Seller Seller { get; set; }
    }
}
