﻿namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;
    using System.Web;

    [Serializable]
    public class ShopCartItem
    {
        public Item theItem { get; set; }
        public int Quantity { get; set; }

        public ShopCartItem(Item item, int quantity = 1)
        {
            this.theItem = item;
            this.Quantity = quantity;
        }

        #region for Cookie only
        public static char CookieSeparator = ':';

        public string ToCookieString()
        {
            return theItem.ItemId.ToString() + ShopCartItem.CookieSeparator + Quantity.ToString();
        }

        public static ShopCartItem CookieStringToItem(OnlineShoppingContext db, string cookieString)
        {
            string[] b = cookieString.Split(ShopCartItem.CookieSeparator);
            if (b.Length == 2)
            {
                int itemid, quantity;
                if (int.TryParse(b[0], out itemid) && int.TryParse(b[1], out quantity))
                {
                    Item item = db.Items.Find(itemid);
                    if (item != null) { return new ShopCartItem(item, int.Parse(b[1])); }
                }
            }
            return null;
        }
        #endregion
    }

    /*************************************************************/
    [Serializable]
    public class ShopCart
    {
        private List<ShopCartItem> ItemList = new List<ShopCartItem>();
        public int Count { get { return ItemList.Count; } }

        public ShopCart()
        {
        }

        public List<ShopCartItem> ToList() { return ItemList; }

        public ShopCartItem this[int index]
        {
            get { return ItemList[index]; }
            set { ItemList[index] = value; }
        }

        public void Add(ShopCartItem item)
        {
            ShopCartItem temp = ItemList.SingleOrDefault(r => r.theItem.ItemId == item.theItem.ItemId);
            if (temp == null)
            {
                ItemList.Add(item);
            }
            else
            {
                temp.Quantity = temp.Quantity + item.Quantity;
            }
        }

        public void Remove(ShopCartItem item)
        {
            ItemList.Remove(item);
        }

        public string RemoveByID(int id)
        {
            ShopCartItem item = ItemList.SingleOrDefault(r => r.theItem.ItemId == id);
            if (item != null)
            {
                ItemList.Remove(item);
                return "The selected item is removed!";
            }
            else
            {
                return "No selected item in cart!";
            }
        }

        public string UpdateQuantity(int itemId, int newQuantity)
        {
            ShopCartItem item = ItemList.SingleOrDefault(r => r.theItem.ItemId == itemId);
            if (item == null)
            {
                using (OnlineShoppingContext db = new OnlineShoppingContext())
                {
                    Item items = db.Items.Find(itemId);
                    if (items != null)
                    {
                        ItemList.Add(new ShopCartItem(items, newQuantity));
                        return "The item is now added into cart!";
                    }
                    else
                    {
                        return "No selected item in cart!";
                    }
                }
            }
            else
            {
                item.Quantity = newQuantity;
                return "Quantity is updated！";
            }
        }
        #region for Cookie only
        public static char CookieSeparator = ',';

        public ShopCart(string strCart)
        {
            string[] a = strCart.Split(ShopCart.CookieSeparator);
            using (OnlineShoppingContext db = new OnlineShoppingContext())
            {
                foreach (string itemString in a)
                {
                    ShopCartItem item = ShopCartItem.CookieStringToItem(db, itemString);
                    if (item != null)
                    {
                        ItemList.Add(item);
                    }
                }
            }
        }

        public string ToCookieString()
        {
            string strCart;
            if (ItemList.Count > 0)
            {
                strCart = ItemList[0].ToCookieString();
                for (int i = 1; i < ItemList.Count; i++)
                {
                    strCart = strCart + ShopCart.CookieSeparator + ItemList[i].ToCookieString();
                }
            }
            else
            {
                strCart = "";
            }
            return strCart;
        }
        #endregion
    }


}
