﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShopping.Models
{
    public static class LoginManager
    {
        public static Account ValidateUser(string userName, string passWord)
        {
            using (OnlineShoppingContext db = new OnlineShoppingContext())
            {
                Account aUser = db.Accounts.SingleOrDefault(r => r.AccountUsername == userName);
                if (aUser == null) return null; // "用户名不存在！";
                if (aUser.AccountPassword != passWord) return null;  // "用户名密码不匹配！";
                return aUser;
            }
        }
    }
}