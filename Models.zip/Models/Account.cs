namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Account")]
    public partial class Account
    {
        public Account()
        {
            Comments = new HashSet<Comment>();
            CompleteOrders = new HashSet<CompleteOrder>();
            Orders = new HashSet<Order>();
            Sellers = new HashSet<Seller>();
            Users = new HashSet<User>();
        }

        public int AccountId { get; set; }

        [Required]
        [StringLength(50)]
        public string AccountUsername { get; set; }

        [Required]
        [StringLength(50)]
        public string AccountPassword { get; set; }

        [Required]
        [StringLength(50)]
        public string ConfirmPassword { get; set; }

        public bool IsAdmin { get; set; }

        public bool IsSeller { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }

        public virtual ICollection<CompleteOrder> CompleteOrders { get; set; }

        public virtual ICollection<Order> Orders { get; set; }

        public virtual ICollection<Seller> Sellers { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}
