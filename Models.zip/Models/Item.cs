namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Item")]
    public partial class Item
    {
        public Item()
        {
            Comments = new HashSet<Comment>();
            CompleteOrders = new HashSet<CompleteOrder>();
            Orders = new HashSet<Order>();
        }

        public int ItemId { get; set; }

        [Required]
        [StringLength(50)]
        public string ItemName { get; set; }

        [Column(TypeName = "image")]
        public byte[] ItemImage { get; set; }

        public int CategoryCode { get; set; }

        public int SellerId { get; set; }

        public int ItemAmount { get; set; }

        public string ItemDescription { get; set; }

        [Column(TypeName = "money")]
        public decimal ItemPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal ItemDiscount { get; set; }

        [Column(TypeName = "money")]
        public decimal ItemAfterDiscountPrice { get; set; }

        public decimal? ItemRating { get; set; }

        public virtual Category Category { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }

        public virtual ICollection<CompleteOrder> CompleteOrders { get; set; }

        public virtual ICollection<Order> Orders { get; set; }

        public virtual Seller Seller { get; set; }
    }
}
