namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Order")]
    public partial class Order
    {
        public Order()
        {
            CompleteOrders = new HashSet<CompleteOrder>();
        }

        public int OrderId { get; set; }

        public int AccountId { get; set; }

        public DateTime OrderTime { get; set; }

        public int SellerId { get; set; }

        public int ItemId { get; set; }

        public int OrderQuantity { get; set; }

        [Column(TypeName = "money")]
        public decimal ItemAfterDiscountPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal OrderTotal { get; set; }

        public virtual Account Account { get; set; }

        public virtual Seller Seller { get; set; }

        public virtual ICollection<CompleteOrder> CompleteOrders { get; set; }

        public virtual Item Item { get; set; }
    }
}
