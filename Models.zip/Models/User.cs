namespace OnlineShopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("User")]
    public partial class User
    {
        public int UserId { get; set; }

        public int AccountId { get; set; }

        [Required]
        [StringLength(50)]
        public string AccountUsername { get; set; }

        [Required]
        [StringLength(50)]
        public string UserName { get; set; }

        [StringLength(50)]
        public string UserSex { get; set; }

        [StringLength(50)]
        public string UserBirthday { get; set; }

        [StringLength(50)]
        public string UserMobile { get; set; }

        [StringLength(50)]
        public string UserEmail { get; set; }

        [StringLength(50)]
        public string UserAddress { get; set; }

        [StringLength(50)]
        public string UserPostCode { get; set; }

        public virtual Account Account { get; set; }
    }
}
