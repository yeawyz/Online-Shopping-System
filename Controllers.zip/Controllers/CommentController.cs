﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineShopping.Models;

namespace OnlineShopping.Controllers
{
    public class CommentController : Controller
    {
        private OnlineShoppingContext db = new OnlineShoppingContext();
        // GET: Comment
        public ActionResult Index()
        {
            return View(db.Comments.ToList());
        }

        public ActionResult GetSearchComments (string id = "")
        {
            List<Comment> CommentList = new List<Comment>();
            if (id == "")
            {            
                CommentList = db.Comments.OrderByDescending(r => r.ItemId).Take(20).ToList();
            }
            else
            {
                List<Item> itemlist = db.Items.Where(r => r.ItemName.Contains(id)).ToList();
                if (itemlist.Count() != 0)
                {
                    for (int i = 0; i < itemlist.Count; i++)
                    {
                        int nowid = itemlist[i].ItemId;
                        Comment nowcomment = db.Comments.FirstOrDefault(r => r.ItemId == nowid);
                        CommentList.Add(nowcomment);
                    }
                }
                else
                {
                    CommentList = db.Comments.OrderByDescending(r => r.ItemId).Take(20).ToList();
                }
            }
            return PartialView(CommentList);
        }
    }
}