﻿using OnlineShopping.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace OnlineShopping.Controllers
{
    public class ItemController : Controller
    {
        private OnlineShoppingContext db = new OnlineShoppingContext();
        string[] AllowedExtensions = { "jpg", "gif", "png", };



        // GET: Items
        public ActionResult Index()
        {
            var items = db.Items.Include(b => b.Category).Include(b => b.Seller);
            return View(items.ToList());
        }


        // GET: Books/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item item = db.Items.Find(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            return View(item);
        }


        // GET: Books/Create
        public ActionResult Create()
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                if (CurrentAcc.IsSeller == true)
                {
                    ViewBag.CategoryCode = new SelectList(db.Categories, "CategoryCode", "CategoryName");
                    ViewBag.SellerId = new SelectList(db.Sellers, "SellerId", "SellerName");
                    return View();
                }
                ViewBag.Message = "用户不是卖家或管理员，不能添加商品！";
                return View("Index");
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }   
            
        }

        // POST: Books/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Item item)
        {
            if (ModelState.IsValid)
            {
                HttpPostedFileBase file = Request.Files["ImageData"];
                int i = UploadImageInDataBase(file, item);
                if (i == 1)
                {
                    return RedirectToAction("Index");
                }  
            }
            ViewBag.Message = "商品信息格式错误！";
            ViewBag.CategoryCode = new SelectList(db.Categories, "CategoryCode", "CategoryName", item.CategoryCode);
            ViewBag.SellerId = new SelectList(db.Sellers, "SellerId", "SellerName", item.SellerId);
            return View(item);
        }

        public int UploadImageInDataBase(HttpPostedFileBase file, Item item)
        {
            item.ItemImage = ConvertToBytes(file);
            Item items = new Item();
            items = item;
            items.ItemImage = item.ItemImage;
            items.ItemRating = 0;

            db.Items.Add(items);
            int i = db.SaveChanges();
            if (i == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        public byte[] ConvertToBytes(HttpPostedFileBase image)
        {
            byte[] imageBytes = null;
            BinaryReader reader = new BinaryReader(image.InputStream);
            imageBytes = reader.ReadBytes((int)image.ContentLength);
            return imageBytes;
        } 


        // GET: Books/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Item item = db.Items.Find(id);
                Seller thisSeller = db.Sellers.FirstOrDefault(r => r.SellerId == item.SellerId);
                if (item == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsSeller == true && thisSeller != null)
                {
                    ViewBag.CategoryCode = new SelectList(db.Categories, "CategoryCode", "CategoryName", item.CategoryCode);
                    ViewBag.SellerId = new SelectList(db.Sellers, "SellerId", "SellerName", item.SellerId);
                    return View(item);
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    ViewBag.CategoryCode = new SelectList(db.Categories, "CategoryCode", "CategoryName", item.CategoryCode);
                    ViewBag.SellerId = new SelectList(db.Sellers, "SellerId", "SellerName", item.SellerId);
                    return View(item);
                }
                else
                {
                    ViewBag.Message = "用户不是卖家或管理员，不能更改商品信息！";
                    return View("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }  
            
        }

        // POST: Books/Edit/5
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Item item)
        {
            if (ModelState.IsValid)
            {
                HttpPostedFileBase file = Request.Files["ImageData2"];
                int i = EditImageInDataBase(file, item);
                if (i == 1)
                {
                    return RedirectToAction("Index");
                }
            }
            ViewBag.Message = "商品信息格式错误！";
            ViewBag.CategoryCode = new SelectList(db.Categories, "CategoryCode", "CategoryName", item.CategoryCode);
            ViewBag.SellerId = new SelectList(db.Sellers, "SellerId", "SellerName", item.SellerId);
            return View(item);
        }

        public int EditImageInDataBase(HttpPostedFileBase file, Item item)
        {
            item.ItemImage = ConvertToBytes(file);
            Item items = new Item();
            items = item;
            items.ItemImage = item.ItemImage;
            items.ItemRating = item.ItemRating;

            db.Entry(items).State = EntityState.Modified;
            int i = db.SaveChanges();
            if (i == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }


        // GET: Books/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Item item = db.Items.Find(id);
                Seller thisSeller = db.Sellers.FirstOrDefault(r => r.SellerId == item.SellerId);
                if (item == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsSeller == true && thisSeller != null)
                {
                    return View(item);
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(item);
                }
                else
                {
                    ViewBag.Message = "用户不是卖家或管理员，不能删除商品！";
                    return View("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            } 

        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Item item = db.Items.Find(id);
            db.Items.Remove(item);
            db.SaveChanges();
            ViewBag.Message = "成功删除商品！";
            return View("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}