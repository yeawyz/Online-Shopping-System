﻿using OnlineShopping.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using System.Configuration;
using System.Drawing;
using System.Data.Entity.Validation;
using System.Diagnostics;

namespace BookStore.Controllers
{
    public class AccountController : Controller
    {
        private OnlineShoppingContext db = new OnlineShoppingContext();
        Account CurrentAcc;
        string LoginUrl, LoginController, LoginAction;
        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            base.Initialize(requestContext);
            ViewBag.Database = db;
            ViewBag.Controller = RouteData.Values.ContainsKey("controller") ? RouteData.Values["controller"].ToString().ToLower() : "home";
            ViewBag.Action = RouteData.Values.ContainsKey("action") ? RouteData.Values["action"].ToString().ToLower() : "index";
            ViewBag.ID = RouteData.Values.ContainsKey("id") ? RouteData.Values["id"].ToString().ToLower() : string.Empty;
            CurrentAcc = (Session["CurrentAcc"] == null) ? null : ((Account)(Session["CurrentUser"]));
            LoginUrl = ConfigurationManager.AppSettings["LoginUrl"];
            if (LoginUrl != null)
            {
                string[] temp = LoginUrl.Split('/');
                LoginController = temp[0];
                LoginAction = temp[1];
            }
        }


        // GET: Accounts
        [HttpGet]
        public ActionResult Index()
        {
            return View(db.Accounts.ToList());
        }


        // GET: Account/Details/5
        [HttpGet]
        public ActionResult Details(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Account thisacc = db.Accounts.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(thisacc);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.AccountId == id)
                {
                    return View(thisacc);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.AccountId != id)
                {
                    ViewBag.Message = "用户不是管理员！";
                    return RedirectToAction("Index");
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }
        }


        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(Account account)
        {
            if (ModelState.IsValid)
            {

                Account aAccount = new Account();
                aAccount.AccountUsername = account.AccountUsername;
                aAccount.AccountPassword = account.AccountPassword;
                aAccount.ConfirmPassword = account.ConfirmPassword;
                aAccount.IsAdmin = account.IsAdmin;
                aAccount.IsSeller = account.IsSeller;
                db.Accounts.Add(aAccount);
                db.SaveChanges();
                if (account.IsSeller == true)
                {
                    Seller seller = new Seller();
                    seller.AccountId = aAccount.AccountId;
                    seller.SellerName = account.AccountUsername;
                    db.Sellers.Add(seller);
                    db.SaveChanges();
                }
                
                LoginModel login = new LoginModel();
                login.UserName = account.AccountUsername;
                login.Password = account.AccountPassword;
                login.RememberMe = false;
                string Result = ValidateUser(login);
                ModelState.Clear();
                ViewBag.Message = "注册成功！";
                return RedirectToAction("Index","Home");
            }
            var errors = ModelState.Select(x => x.Value.Errors)
                           .Where(y => y.Count > 0)
                           .ToList();
            //ViewBag.Message = "注册数据错误！";
            return View(errors);

        }


        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(LoginModel model, string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            string Result;
            if (ModelState.IsValid) { Result = ValidateUser(model); }
            else { Result = "用户名或密码不正确。"; }
            if (Result == "登录成功！")
            {
                return RedirectToLocal(returnUrl);
            }
            else
            {
                ModelState.AddModelError("", Result);
                return View(model);
            }
        }


        private string ValidateUser(LoginModel model)
        {
            string Result;
            Account aUser = db.Accounts.SingleOrDefault(r => r.AccountUsername == model.UserName);
            if (aUser == null) { Result = "用户名不存在！"; }
            else if (aUser.AccountPassword != model.Password) { Result = "用户名密码不匹配！"; }
            else  //校验通过
            {
                Session["CurrentAcc"] = aUser;
                if (model.RememberMe)
                {
                    HttpCookie TokenCookie = new HttpCookie("Token");
                    TokenCookie.Value = aUser.AccountId.ToString() + "/" + aUser.AccountUsername;
                    TokenCookie.Expires = DateTime.Now.AddDays(7);
                    //TokenCookie.Expires = DateTime.Now.AddMinutes(10);
                    TokenCookie.HttpOnly = true;
                    Response.Cookies.Add(TokenCookie);
                    //Response.Cookies["Token"] = aUser.Id.ToString() + "/" + aUser.LoginName + "/" + aUser.Name;
                }
                Result = "登录成功！";
            }
            return Result;
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        public ActionResult LogOff(string returnUrl)
        {
            Session["CurrentAcc"] = null;
            Response.Cookies.Remove("Token");

            return RedirectToLocal(returnUrl);
        }


        // GET: Customers/Create
        public ActionResult Create()
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                if (CurrentAcc.IsAdmin == true)
                {
                    return View();
                }
                ViewBag.Message = "用户不是管理员，无法添加用户！";
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }   
        }

        // POST: Customers/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Account account)
        {
            if (ModelState.IsValid)
            {
                db.Accounts.Add(account);
                db.SaveChanges();
                if (account.IsSeller == true)
                {
                    Seller seller = new Seller();
                    seller.AccountId = account.AccountId;
                    seller.SellerName = account.AccountUsername;
                    db.Sellers.Add(seller);
                    db.SaveChanges();
                }
                ViewBag.Message = "成功添加用户！";
                return RedirectToAction("Index");
            }
            else
            {
                return View("Index");
            }
        }

        // GET: Customers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Account thisacc = db.Accounts.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(thisacc);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.AccountId == id)
                {
                    return View(thisacc);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.AccountId != id)
                {
                    ViewBag.Message = "用户不是管理员！";
                    return RedirectToAction("Index");
                }
                else 
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }  
        }

        // POST: Customers/Edit/5
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Account thisacc)
        {
            if (ModelState.IsValid)
            {
                db.Entry(thisacc).State = EntityState.Modified;
                db.SaveChanges();
                ViewBag.Message = "成功更改用户登录信息！";
                return RedirectToAction("Index");
            }
            return View("Index");
        }

        // GET: Customers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Account thisacc = db.Accounts.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(thisacc);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.AccountId == id)
                {
                    return View(thisacc);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.AccountId != id)
                {
                    ViewBag.Message = "用户不是管理员！";
                    return RedirectToAction("Index");
                }
                else
                {
                    return View("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            } 
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Account account = db.Accounts.Find(id);
            if (account.IsSeller == true)
            {
                Seller seller = db.Sellers.SingleOrDefault(r => r.SellerId == 9);
                db.Sellers.Remove(seller);
                db.SaveChanges();
            }
            db.Accounts.Remove(account);
            db.SaveChanges();
            ViewBag.Message = "成功删除用户！";
            return RedirectToAction("Index");
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        #region private method
        public ActionResult VerifyImage()
        {
            string vCode = CreateRandomCode(4);
            Session["VerifyCode"] = vCode;
            //byte[] bytes = ValidateCode.CreateValidateGraphic(vCode);  //图形较小
            //byte[] bytes = ValidateCode.CreateImage(vCode);  //图形要大点
            byte[] bytes = CreateImage(vCode);
            return File(bytes, @"image/jpeg");
        }
        private string CreateRandomCode(int length)
        {
            int rand;
            char code;
            string randomcode = String.Empty;
            //生成一定长度的验证码  
            System.Random random = new Random();
            for (int i = 0; i < length; i++)
            {
                rand = random.Next();
                if (rand % 3 == 0)
                {
                    code = (char)('A' + (char)(rand % 26));
                }
                else
                {
                    code = (char)('0' + (char)(rand % 10));
                }
                randomcode += code.ToString();
            }
            return randomcode;
        }

        private byte[] CreateImage(string randomcode)
        {
            //随机转动角度  
            int randAngle = 25;
            int mapwidth = (int)(randomcode.Length * 26);
            //创建图片背景  
            using (Bitmap map = new Bitmap(mapwidth, 30))
            {
                using (Graphics graph = Graphics.FromImage(map))
                {
                    graph.Clear(Color.AliceBlue);//清除画面，填充背景  
                    graph.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;//模式  
                    Random rand = new Random();
                    //背景噪点生成 
                    Pen blackPen = new Pen(Color.LightGray, 0);
                    for (int i = 0; i < 50; i++)
                    {
                        int x = rand.Next(3, map.Width - 3);
                        int y = rand.Next(3, map.Height - 3);
                        graph.DrawRectangle(blackPen, x, y, 1, 1);
                    }


                    //验证码旋转，防止机器识别    
                    char[] chars = randomcode.ToCharArray();//拆散字符串成单字符数组  
                    //文字距中  
                    StringFormat format = new StringFormat(StringFormatFlags.NoClip);
                    format.Alignment = StringAlignment.Center;
                    format.LineAlignment = StringAlignment.Center;
                    //定义颜色  
                    Color[] c = { Color.Black, Color.Red, Color.DarkBlue, Color.Green, Color.Orange, Color.Brown, Color.DarkCyan, Color.Purple };
                    //定义字体  
                    string[] font = { "Verdana", "Microsoft Sans Serif", "Comic Sans MS", "Arial", "宋体" };
                    for (int i = 0; i < chars.Length; i++)
                    {
                        int cindex = rand.Next(c.Length);
                        int findex = rand.Next(font.Length);
                        Font f = new System.Drawing.Font(font[findex], 18, System.Drawing.FontStyle.Bold);//字体样式(参数2为字体大小)  
                        Brush b = new System.Drawing.SolidBrush(c[cindex]);
                        Point dot = new Point(22, 18);
                        float angle = rand.Next(-randAngle, randAngle);//转动的度数  
                        graph.TranslateTransform(dot.X - 5, dot.Y);//移动光标到指定位置  
                        graph.RotateTransform(angle);
                        graph.DrawString(chars[i].ToString(), f, b, 1, 1, format);
                        graph.RotateTransform(-angle);//转回去  
                        graph.TranslateTransform(5, -dot.Y);//移动光标到指定位置  
                    }
                    //生成图片  
                    using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                    {
                        map.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);

                        return ms.ToArray();
                    }
                }
            }
        }

        public ActionResult CheckVerifyCode(string VerifyCode)
        {
            string vCode = (string)Session["VerifyCode"];
            if (vCode == VerifyCode) { return Json(true, JsonRequestBehavior.AllowGet); }
            else { return Json(false, JsonRequestBehavior.AllowGet); }
        }
        #endregion
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}