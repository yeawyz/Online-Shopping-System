﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineShopping.Models;
using System.Data.Entity;

namespace OnlineShopping.Controllers
{
    public class CompleteOrderController : Controller
    {
        private OnlineShoppingContext db = new OnlineShoppingContext();
        protected override void OnAuthentication(System.Web.Mvc.Filters.AuthenticationContext filterContext)
        {
            base.OnAuthentication(filterContext);
            if (Session["CurrentAcc"] == null)
            {
                filterContext.Result = RedirectToAction("Login", "Account", new { ReturnUrl = Request.Url });
            }
        }

        // GET: CompleteOrder
        public ActionResult Index()
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(db.CompleteOrders.ToList());
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.IsSeller == true)
                {
                    List<CompleteOrder> nowcorder = new List<CompleteOrder>();
                    List<CompleteOrder> allcorder = db.CompleteOrders.ToList();
                    Seller thisseller =  db.Sellers.FirstOrDefault(r => r.AccountId == CurrentAcc.AccountId);
                    for (int i = 0; i < allcorder.Count; i++)
                    {
                        if (allcorder[i].SellerId == thisseller.SellerId || allcorder[i].AccountId == CurrentAcc.AccountId)
                        {
                            nowcorder.Add(allcorder[i]);
                        }
                    }
                    return View(nowcorder);
                }
                if (CurrentAcc.IsAdmin == false && CurrentAcc.IsSeller == false)
                {
                    List<CompleteOrder> nowcorder = new List<CompleteOrder>();
                    List<CompleteOrder> allcorder = db.CompleteOrders.ToList();
                    for (int i = 0; i < allcorder.Count; i++)
                    {
                        if (allcorder[i].AccountId == CurrentAcc.AccountId)
                        {
                            nowcorder.Add(allcorder[i]);
                        }
                    }
                    return View(nowcorder);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login", "Home");
            }
        }

        public ActionResult MakeComment(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                CompleteOrder completeorder = db.CompleteOrders.Find(id);
                Comment nowcomment = new Comment();
                nowcomment.AccountId = completeorder.AccountId;
                nowcomment.ItemId = completeorder.ItemId;
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(nowcomment);
                }
                if (CurrentAcc.IsAdmin == false && completeorder.AccountId == CurrentAcc.AccountId)
                {
                    return View(nowcomment);
                }
                else
                {
                    return Content("You can only make comment if you are buyer or admin!");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: Orders/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult MakeComment(Comment nowcomment)
        {
            Account CurrentAcc = (Account)(Session["CurrentAcc"]);
            
            if (ModelState.IsValid)
            {
                Item item = db.Items.Find(nowcomment.ItemId);
                List<Comment> allcomment = db.Comments.Where(r => r.ItemId == nowcomment.ItemId).ToList();
                if (item.ItemRating == 0)
                {
                    item.ItemRating = nowcomment.Rating;
                    db.Entry(item).State = EntityState.Modified;
                    db.SaveChanges();
                }
                if (item.ItemRating != 0)
                {
                    decimal? temp = item.ItemRating * allcomment.Count();
                    item.ItemRating = (temp + nowcomment.Rating) / (allcomment.Count() + 1);
                    db.Entry(item).State = EntityState.Modified;
                    db.SaveChanges();
                }
                Comment newComment = new Comment();
                newComment.AccountId = nowcomment.AccountId;
                newComment.ItemId = nowcomment.ItemId;
                newComment.CommentTime = DateTime.Now;
                newComment.CommentContent = nowcomment.CommentContent;
                newComment.Rating = nowcomment.Rating;
                db.Comments.Add(newComment);
                db.SaveChanges();
                return RedirectToAction("Index","Comment");
            }

            return View(nowcomment);
        }
    }
}