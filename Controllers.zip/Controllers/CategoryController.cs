﻿using OnlineShopping.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace OnlineShopping.Controllers
{
    public class CategoryController : Controller
    {
        private OnlineShoppingContext db = new OnlineShoppingContext();

        // GET: Categories
        public ActionResult Index()
        {
            return View(db.Categories.ToList());
        }

        // GET: Category/Details/5
        public ActionResult Details(int id)
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Category category = db.Categories.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true || CurrentAcc.IsAdmin == false)
                {
                    return View(category);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }
        }

        // GET: ArchiveTypes/Create
        public ActionResult Create()
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                if (CurrentAcc.IsAdmin == true)
                {
                    return View();
                }
                ViewBag.Message = "用户不是管理员，无法添加类别！";
                return View("Index");
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }   
        }

        // POST: ArchiveTypes/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Category category)
        {
            if (ModelState.IsValid)
            {
                db.Categories.Add(category);
                db.SaveChanges();
                ViewBag.Message = "类别已添加！";
                return View("Index");
            }
            ViewBag.Message = "数据有错！";
            return View("Create");
        }

        // GET: ArchiveTypes/Edit/5
        public ActionResult Edit(int id)
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Category category = db.Categories.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(category);
                }
                if (CurrentAcc.IsAdmin == false)
                {
                    ViewBag.Message = "用户不是管理员！";
                    return View("Index");
                }
                else 
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }
        }

        // POST: ArchiveTypes/Edit/5
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                db.Entry(category).State = EntityState.Modified;
                db.SaveChanges();
                ViewBag.Message = "类别信息已经修改！";
                return View("Index");
            }
            ViewBag.Message = "数据格式有错！";
            return View("Edit");
        }


        public ActionResult Delete(int id)
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Category category = db.Categories.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(category);
                }
                else
                {
                    ViewBag.Message = "用户不是管理员！";
                    return View("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }

        }

        // GET: ArchiveTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirm(int id)
        {
            int UseCount = db.Items.Where(r => r.CategoryCode == id).Count();
            if (UseCount > 0)
            {
                ViewBag.Message = "该类别正被书使用着，不能删除！";
                return View("Index"); 
            }
            Category category = db.Categories.Find(id);
            if (category == null) { return HttpNotFound(); }
            db.Categories.Remove(category);
            db.SaveChanges();
            ViewBag.Message = "类别已删除！";
            return View("Index");
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}