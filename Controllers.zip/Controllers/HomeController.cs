﻿using OnlineShopping.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineShopping.Controllers
{
    public class HomeController : Controller
    {
        public OnlineShoppingContext db = new OnlineShoppingContext();
        List<Category> CategoryList;
        SelectList CategorySelector;
        Account CurrentAcc;
        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            base.Initialize(requestContext);
            CategoryList = db.Categories.ToList();
            CategorySelector = new SelectList(CategoryList, "CategoryCode", "CategoryName", "");
            ViewBag.Database = db;
            ViewBag.Controller = RouteData.Values.ContainsKey("controller") ? RouteData.Values["controller"].ToString().ToLower() : "home";
            ViewBag.Action = RouteData.Values.ContainsKey("action") ? RouteData.Values["action"].ToString().ToLower() : "index";
            ViewBag.ID = RouteData.Values.ContainsKey("id") ? RouteData.Values["id"].ToString().ToLower() : string.Empty;
            CurrentAcc = (Session["CurrentAcc"] == null) ? null : ((Account)(Session["CurrentAcc"]));
        }


        public ActionResult Index()
        {
            List<Item> ItemList = db.Items.OrderByDescending(r => r.ItemId).Take(20).ToList();
            ViewBag.ItemList = ItemList;
            return View(db.Categories.ToList());
        }


        public ActionResult GetSearchItems(string id = "")
        {
            List<Item> ItemList;
            if (id == "")
            {
                ItemList = db.Items.OrderByDescending(r => r.ItemId).Take(20).ToList();
                TempData["tempsearch"] = ItemList;
            }
            else
            {
                ItemList = db.Items.Where(r => r.ItemName.Contains(id)).OrderByDescending(r => r.ItemId).ToList();
                TempData["tempsearch"] = ItemList;
            }
            return PartialView(ItemList);
        }

        [HttpPost]
        public ActionResult GetItemWithinPrice(FormCollection form)
        {
            string maxp = form["MaxPrice"];
            string minp = form["MinPrice"];
            int Value1;
            int Value2;
            bool isnumber1 = int.TryParse(maxp,out Value1);
            bool isnumber2 = int.TryParse(minp,out Value2);
            if (isnumber1 == false || isnumber2 == false) 
            {
                return Content("Please Input A Valid Number");
            }
            int Maxp = int.Parse(maxp);
            int Minp = int.Parse(minp);
            if (TempData["tempsearch"] == null)
            {
                TempData["tempsearch"] = new List<Item>();
            }
            List<Item> ItemList = TempData["tempsearch"] as List<Item>;
            List<Item> NowItemList = new List<Item>();
            if (ItemList.Count() == 0) 
            {
                ItemList = db.Items.OrderByDescending(r => r.ItemId).Take(20).ToList();
            }
            if (Maxp == 0)
                {
                    ItemList.Sort();
                    NowItemList = ItemList;
                }
            if (Maxp != 0)
                {
                    if (Maxp > Minp)
                    {
                        for (int i = 0; i < ItemList.Count; i++)
                        {
                            if (ItemList[i].ItemAfterDiscountPrice <= Maxp && ItemList[i].ItemAfterDiscountPrice >= Minp)
                            {
                                NowItemList.Add(ItemList[i]);
                            }
                        }
                    }
                    if (Maxp == Minp)
                    {
                        for (int i = 0; i < ItemList.Count; i++)
                        {
                            if (ItemList[i].ItemAfterDiscountPrice == Maxp)
                            {
                                NowItemList.Add(ItemList[i]);
                            }
                        }
                    }
                    if (Maxp < Minp)
                    {
                        int tempp = Maxp;
                        Maxp = Minp;
                        Minp = tempp;
                        for (int i = 0; i < ItemList.Count; i++)
                        {
                            if (ItemList[i].ItemAfterDiscountPrice <= Maxp && ItemList[i].ItemAfterDiscountPrice >= Minp)
                            {
                                NowItemList.Add(ItemList[i]);
                            }
                        }
                    }
                }                    
            return PartialView(NowItemList);
        }

        public ActionResult GetCategoryItems(string id = "")
        {
            string newid = id.Replace("_", "&");
            List<Item> nowItemList = new List<Item>();
            Category nowCategory = new Category();
            if (newid == null)
            {
                return HttpNotFound();
            }
            else
            {
                nowCategory = db.Categories.FirstOrDefault(r => r.CategoryName == newid);
                List<Item> itemlist = db.Items.ToList();
                for (int i = 0; i < itemlist.Count; i++)
                {
                    if (itemlist[i].CategoryCode == nowCategory.CategoryCode)
                    {
                        nowItemList.Add(itemlist[i]);
                    }
                }
                TempData["tempsearch"] = nowItemList;
            }
           
            return PartialView(nowItemList);
        }

        public ActionResult PriceAscending()
        {
            if (TempData["tempsearch"] == null)
            {
                TempData["tempsearch"] = new List<Item>();
            }
            List<Item> nowItemList = new List<Item>();
            List<Item> ItemList = TempData["tempsearch"] as List<Item>;
            List<Item> AllItem = db.Items.ToList();
            if (ItemList.Count() == 0)
            {
                ItemList = db.Items.OrderByDescending(r => r.ItemId).Take(20).ToList();
            }
            nowItemList = ItemList.OrderBy(p => p.ItemAfterDiscountPrice).ToList();
            return PartialView(nowItemList);
        }

        public ActionResult PriceDescending()
        {
            if (TempData["tempsearch"] == null)
            {
                TempData["tempsearch"] = new List<Item>();
            }
            List<Item> nowItemList = new List<Item>();
            List<Item> ItemList = TempData["tempsearch"] as List<Item>;
            List<Item> AllItem = db.Items.ToList();
            if (ItemList.Count() == 0)
            {
                ItemList = db.Items.OrderByDescending(r => r.ItemId).Take(20).ToList();
            }
            nowItemList = ItemList.OrderByDescending(p => p.ItemAfterDiscountPrice).ToList();
            return PartialView(nowItemList);
        }

        [HttpPost]
        public ActionResult GetSearchRating(FormCollection form)
        {
            
            string rating = form["Rating"];
            if (rating == "5-4")
            {
                List<Item> itemwrate = db.Items.Where(r => r.ItemRating > (decimal)4 && r.ItemRating <= (decimal)5).ToList();
                TempData["tempsearch"] = itemwrate;
                return PartialView(itemwrate);
            }
            if (rating == "4-3")
            {
                List<Item> itemwrate = db.Items.Where(r => r.ItemRating > (decimal)3 && r.ItemRating <= (decimal)4).ToList();
                TempData["tempsearch"] = itemwrate;
                return PartialView(itemwrate);
            }
            if (rating == "3-2")
            {
                List<Item> itemwrate = db.Items.Where(r => r.ItemRating > (decimal)2 && r.ItemRating <= (decimal)3).ToList();
                TempData["tempsearch"] = itemwrate;
                return PartialView(itemwrate);
            }
            if (rating == "2-1")
            {
                List<Item> itemwrate = db.Items.Where(r => r.ItemRating > (decimal)1 && r.ItemRating <= (decimal)2).ToList();
                TempData["tempsearch"] = itemwrate;
                return PartialView(itemwrate);
            }
            if (rating == "Lower than 1")
            {
                List<Item> itemwrate = db.Items.Where(r => r.ItemRating >= (decimal)0 && r.ItemRating <= (decimal)1).ToList();
                TempData["tempsearch"] = itemwrate;
                return PartialView(itemwrate);
            }
            return PartialView();
        }


        [HttpPost]
        public ActionResult AddToShopCart(int id)
        {
            ShopCart theCart = (Session["ShopCart"] == null) ? new ShopCart() : (ShopCart)Session["ShopCart"];
            Item theItem = db.Items.Find(id);
            if (theItem != null)
            {
                theCart.Add(new ShopCartItem(theItem));
                Session["ShopCart"] = theCart;
            }
            return Content("The item is added into your cart！");
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }


        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}