﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineShopping.Models;
using System.Data.Entity;

namespace OnlineShopping.Controllers
{
    public class ShopCartController : Controller
    {
        //BookStoreEntities db = new BookStoreEntities();
        private OnlineShoppingContext db = new OnlineShoppingContext();
        ShopCart theCart;
        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            base.Initialize(requestContext);
        }
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            theCart = (Session["ShopCart"] == null) ? new ShopCart() : (ShopCart)Session["ShopCart"];
        }

        // GET: ShopCart
        public ActionResult Index()
        {
            return View(theCart.ToList());
        }

        [HttpPost]
        public ActionResult UpdateQuantity(int itemId, int newQuantity)
        {
            string Result = theCart.UpdateQuantity(itemId, newQuantity);
            return Content(Result);
        }

        [HttpPost]
        public ActionResult DeleteItem(int itemId)
        {
            string Result = theCart.RemoveByID(itemId);
            return Content(Result);
        }

        public ActionResult TurnToOrder()
        {
            Account theAcc = (Session["CurrentAcc"] == null) ? null : ((Account)(Session["CurrentAcc"]));
            if (theCart.Count > 0 && theAcc != null)
            {
                string generateresult = GenerateOrder(theCart, theAcc);
                if (generateresult == "addsuccess")
                {
                    return RedirectToAction("Index", "Order");
                }
                return Content("Fail to make order!");
                
            }
            return Content("The cart is empty");
        }

        #region private method
        private string GenerateOrder(ShopCart theCart, Account theAcc)
        {
            //Order aOrder = new Order();
            //aOrder.AccountId = theAcc.AccountId;
            //aOrder.OrderTime = DateTime.Now;
            //decimal odrmoney = 0;
            //for (int k = 0; k < theCart.Count; k++)
            //{
            //    odrmoney += ((decimal)theCart[k].theItem.ItemAfterDiscountPrice * theCart[k].Quantity);
            //}
            //aOrder.OrderTotal = odrmoney;
            for (int i = 0; i < theCart.Count; i++)
            {
                Order aOrder = new Order();
                aOrder.ItemId = theCart[i].theItem.ItemId;
                aOrder.AccountId = theAcc.AccountId;
                aOrder.OrderTime = DateTime.Now;
                aOrder.SellerId = theCart[i].theItem.SellerId;
                decimal odrmoney = 0;
                for (int k = 0; k < theCart.Count; k++)
                {
                    odrmoney += ((decimal)theCart[k].theItem.ItemAfterDiscountPrice * theCart[k].Quantity);
                }
                aOrder.OrderTotal = odrmoney;
                aOrder.OrderQuantity = theCart[i].Quantity;
                aOrder.ItemAfterDiscountPrice = (decimal)theCart[i].theItem.ItemAfterDiscountPrice;
                db.Orders.Add(aOrder);
                Item nowitem = db.Items.Find(theCart[i].theItem.ItemId);
                nowitem.ItemAmount = (nowitem.ItemAmount - theCart[i].Quantity);
                db.Entry(nowitem).State = EntityState.Modified;
                db.SaveChanges();
            }
            //for (int o = 0; o < theCart.Count; o++)
            //{
            //    Item nowitem = db.Items.Find(theCart[k].theItem.ItemId);
            //    nowitem.ItemAmount = (nowitem.ItemAmount - theCart[k].Quantity);
            //    db.Entry(nowitem).State = EntityState.Modified;
            //    db.SaveChanges();
                
            //}
            ModelState.Clear();
            string generateresult = "addsuccess";
            return generateresult;
        }
        #endregion

        public ActionResult Select()
        {
            return View();
        }
    }
}