﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineShopping.Models;
using System.Net;
using System.Data.Entity;

namespace OnlineShopping.Controllers
{
    public class OrderController : Controller
    {
        //private BookStoreEntities db = new BookStoreEntities();
        private OnlineShoppingContext db = new OnlineShoppingContext();
        protected override void OnAuthentication(System.Web.Mvc.Filters.AuthenticationContext filterContext)
        {
            base.OnAuthentication(filterContext);
            if (Session["CurrentAcc"] == null)
            {
                filterContext.Result = RedirectToAction("Login", "Account", new { ReturnUrl = Request.Url });
            }
        }
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {
            base.OnAuthorization(filterContext);
            /*
            //系统管理员39；活动管理员64；
            List<SystemRole> RoleList = (List<SystemRole>)CurrentUser.RoleList;
            bool HasRight = false;
            foreach (SystemRole item in RoleList)
            {
                if ((item.ID == 39) || (item.ID == 64)) { HasRight = true; break; }
            }
            if (!(HasRight))
            { filterContext.Result = RedirectToAction("Login", "Customers", new { area = "", ReturnUrl = Request.Url }); }
            */
        }

        // GET: Order
        public ActionResult Index()
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(db.Orders.ToList());
                }
                if (CurrentAcc.IsAdmin == false)
                {
                    List<Order> noworder = new List<Order>();
                    List<Order> allorder = db.Orders.ToList();
                    for (int i = 0; i < allorder.Count; i++)
                    {
                        if (allorder[i].AccountId == CurrentAcc.AccountId)
                        {
                            noworder.Add(allorder[i]);
                        }
                    }
                    return View(noworder);
                }
                else
                {
                    return RedirectToAction("Index","Home");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login", "Home");
            }
        }

        // GET: Order/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // GET: Orders/Create
        public ActionResult Create()
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View();
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: Orders/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Order order)
        {
            Account CurrentAcc = (Account)(Session["CurrentAcc"]);
            order.AccountId = CurrentAcc.AccountId;
            if (ModelState.IsValid)
            {
                db.Orders.Add(order);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(order);
        }

        // GET: Order/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Order order = db.Orders.Find(id);
                if (order == null)
                {
                return HttpNotFound();
                }
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(order);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login","Home");
            }
        }

        // POST: Order/Edit/5
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Order order)
        {
            if (ModelState.IsValid)
            {
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Message = "The format of data is incorrect!";
            return View(order);
        }

        // GET: Orders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Order order = db.Orders.Find(id);
                if (order == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true)
                {
                    return View(order);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: Orders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Order order = db.Orders.Find(id);
            db.Orders.Remove(order);
            db.SaveChanges();
            return RedirectToAction("Index");
        }


        public ActionResult ReceiveOrder(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Order order = db.Orders.Find(id);
                if (order == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true || CurrentAcc.IsSeller == true || order.AccountId == CurrentAcc.AccountId)
                {
                    return View(order);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "Please login to proceed!";
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: Orders/Delete/5
        [HttpPost, ActionName("ReceiveOrder")]
        [ValidateAntiForgeryToken]
        public ActionResult ReceiveOrder(int id)
        {
            Order order = db.Orders.Find(id);
            CompleteOrder corder = new CompleteOrder();
            corder.OrderId = order.OrderId;
            corder.OrderReceiveTime = DateTime.Now;
            corder.AccountId = order.AccountId;
            corder.OrderTime = order.OrderTime;
            corder.SellerId = order.SellerId;
            corder.ItemId = order.ItemId;
            corder.OrderQuantity = order.OrderQuantity;
            corder.ItemAfterDiscountPrice = order.ItemAfterDiscountPrice;
            corder.OrderTotal = order.OrderTotal;
            db.CompleteOrders.Add(corder);
            db.SaveChanges();
            return RedirectToAction("Index","CompleteOrder");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}