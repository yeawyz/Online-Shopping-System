﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineShopping.Models;
using System.Net;
using System.Data.Entity;

namespace OnlineShopping.Controllers
{
    public class UserController : Controller
    {
        private OnlineShoppingContext db = new OnlineShoppingContext();

        // GET: User
        public ActionResult Index()
        {
            return View(db.Users.ToList());
        }

        public ActionResult Create(int id)
        {
            if (Session["CurrentAcc"] != null)
            {
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                Account thisAcc = db.Accounts.Find(id);
                if (CurrentAcc.IsAdmin == true || CurrentAcc.AccountId == id)
                {
                    User nowuser = new User();
                    nowuser.AccountId = id;
                    nowuser.AccountUsername = thisAcc.AccountUsername;
                    return View(nowuser);
                }
                ViewBag.Message = "用户不是管理员，无法添加用户！";
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(User user)
        {
            if (ModelState.IsValid)
            {
                db.Users.Add(user);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(user);
            }
        }

        public ActionResult Edit(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                User thisuser = db.Users.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true || CurrentAcc.AccountId == thisuser.AccountId)
                {
                    return View(thisuser);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(User thisuser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(thisuser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(thisuser);
        }

        public ActionResult Delete(int? id)
        {
            if (Session["CurrentAcc"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Account CurrentAcc = (Account)(Session["CurrentAcc"]);
                User thisuser = db.Users.Find(id);
                if (CurrentAcc == null)
                {
                    return HttpNotFound();
                }
                if (CurrentAcc.IsAdmin == true || CurrentAcc.AccountId == thisuser.AccountId)
                {
                    return View(thisuser);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                ViewBag.Message = "请先进行登录！";
                return View("Login");
            }
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            User thisuser = db.Users.Find(id);
            db.Users.Remove(thisuser);
            db.SaveChanges();
            ViewBag.Message = "成功删除用户！";
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}